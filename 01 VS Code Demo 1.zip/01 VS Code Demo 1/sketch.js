// Project Title
// Your Name
// Date
//
// Extra for Experts:
// - describe what you did to take this project "above and beyond"


function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  //background(220);
  circle(mouseX, height/2, 100);
  print(frameCount);
}


function keyPressed(){
  background(255, 200, 150);
}
